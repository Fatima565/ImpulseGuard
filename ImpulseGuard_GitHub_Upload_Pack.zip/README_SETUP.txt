IMPULSEGUARD — FIREBASE FIX PACKAGE
=====================================

WHAT THIS FIXES
- AI Insights now call OpenRouter through a private Firebase Function.
- Roast My Spending uses the same working AI endpoint.
- Receipt Scanner sends images through the same private endpoint.
- The OpenRouter key is no longer exposed in index.html or GitHub.
- Spending Wrapped appears automatically when transactions exist.
- PWA manifest is linked correctly.
- Install buttons stay hidden until Chrome provides the real install prompt.
- Service worker ignores POST/API/extension requests and uses cache v3.

IMPORTANT FIRST
Your old OpenRouter key was visible in index.html. Revoke/delete that key in OpenRouter and create a new one. Never paste the new key into index.html, GitHub, firebase.json, or any .env file committed to GitHub.

FOLDER LAYOUT
- public/index.html
- public/manifest.json
- public/sw.js
- public/icon-192.png  (add/copy your existing icon)
- public/icon-512.png  (add/copy your existing icon)
- functions/index.js
- functions/package.json
- firebase.json
- .firebaserc

DEPLOY STEPS (WINDOWS / VS CODE TERMINAL)
1. Put your existing icon-192.png and icon-512.png inside the public folder.
2. Open this impulseguard_firebase_fix folder in VS Code.
3. Install/update Firebase CLI:
   npm install -g firebase-tools
4. Log in:
   firebase login
5. Install Function packages:
   cd functions
   npm install
   cd ..
6. Save the NEW OpenRouter key securely in Firebase Secret Manager:
   firebase functions:secrets:set OPENROUTER_API_KEY
   Paste the new key when the terminal asks. It will not be committed to GitHub.
7. Deploy the Function and website together:
   firebase deploy --only functions,hosting

FIREBASE BILLING NOTE
Production Cloud Functions require the Firebase Blaze plan. Blaze still includes a no-cost usage tier, but a billing account must be linked. Set a small Google Cloud budget alert before deployment.

AFTER DEPLOYMENT — CLEAR THE OLD SERVICE WORKER
1. Open impulseguard.dev in Chrome.
2. Press F12.
3. Application > Service Workers > Unregister.
4. Application > Storage > Clear site data.
5. Close the tab, reopen the site, and hard refresh with Ctrl+Shift+R.

TEST IN THIS ORDER
1. Log in.
2. Reports > analyse spending.
3. Vibes > Roast My Spending.
4. Add Transaction > scan a clear receipt photo.
5. Vibes > confirm Wrapped appears automatically.
6. Reload once; the real Install App prompt/button should appear only when Chrome considers the PWA installable.

GITHUB
You can push this entire folder to GitHub. The actual OpenRouter key is stored in Firebase Secret Manager, not in the repository.

If Firebase asks whether to overwrite files during init, do not run firebase init over this package; the required firebase.json and functions files are already included.
